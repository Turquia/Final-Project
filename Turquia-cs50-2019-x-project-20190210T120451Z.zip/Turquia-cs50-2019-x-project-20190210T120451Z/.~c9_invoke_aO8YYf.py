import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions
from werkzeug.security import check_password_hash, generate_password_hash


from helpers import apology, login_required, lookup, usd, beta

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached


@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.route("/")
@login_required
def index():
    # remembers the user
    id = session['user_id']
    # set an int to store the value of the stocks
    m = db.execute("SELECT cash FROM users WHERE id =:id", id=id)
    cashathand = m[0]['cash']
    cash = 0
    stocks = db.execute("SELECT symbol, quantity FROM portfolio WHERE id = :id", id=id)
    for stock in stocks:
        s = stock["symbol"]
        q = stock["quantity"]
        tmp = lookup(s)
        cp = tmp["price"]
        pp = cp*q
        db.execute("UPDATE portfolio SET price=:price, total=:total WHERE id=:id AND symbol=:symbol",
                   price=usd(cp), total=usd(pp), id=id, symbol=s)
        cash = cash + pp

    totalcash = cash + cashathand
    data = db.execute("SELECT symbol,name,quantity,price,total FROM portfolio WHERE id=:id", id=id)

    return render_template("index.html", stocks=data, cash=usd(cashathand), total=usd(totalcash))


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    # user reached route via post
    if request.method == "POST":

        quanti = request.form.get("shares")
        symbol = request.form.get("symbol")

        # ensure symbol and number of shares are submitted
        if not symbol:
            return apology("Symbol could not be found")
        if not quanti:
            return apology("Please indicate the number of shares you would like to buy")

        try:
            quant = int(quanti)
        except:
            return apology("Only integers dude")

        if quant <= 0:
            return apology("Only positive numbers can be bought")

        purchlist = lookup(symbol)
        if not purchlist:
            return apology("Cy@ -NB3 2K15")
        bet = beta(symbol)
        if not bet:
            return apology("beta not found")
        p = purchlist['price']
        s = purchlist['symbol']
        n = purchlist['name']
        id = session['user_id']
        m = db.execute("SELECT cash FROM users WHERE id = :id", id=id)

        money = m[0]['cash']

        if money < p * quant:
            return apology("You are poor")
        oldq = db.execute("SELECT quantity FROM portfolio WHERE id=:id AND symbol=:symbol", id=id, symbol=s)
        if not oldq:
            db.execute("INSERT INTO portfolio (id, symbol, name, quantity, price, total, beta) VALUES (:id, :symbol, :name, :quantity, :price,:total,:beta)",
                       id=id, symbol=s, name=n, quantity=quant, price=p, total=0, beta=bet)
        else:

            oq=oldq[0]['quantity']

            db.execute("UPDATE portfolio SET quantity=:quantity WHERE id=:id AND symbol=:symbol", quantity= oq+quant, id=id, symbol=s)


        db.execute("UPDATE users SET cash = :cash  WHERE id = :id", id=id, cash=money - p*quant)

        db.execute("INSERT INTO history (id,price,quantity,symbol) VALUES (:id,:price,:quantity,:symbol)",
                       id=id, price=usd(p), quantity=quant, symbol=s)

        return redirect("/")
    else:
        return render_template("buy.html")



@app.route("/history")
@login_required
def history():

    id = session["user_id"]
    transactions = db.execute("SELECT * FROM history WHERE id = :id", id=id)
    return render_template("history.html", transactions=transactions)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/quote")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/addcash", methods=["GET", "POST"])
@login_required
def addcash():
    if request.method == "POST":
        id = session['user_id']
        cashadd = request.form.get("addedcash")
        if not cashadd:
            return apology("Please enter the amount")
        m = db.execute("SELECT cash FROM users WHERE id =:id", id=id)
        cashadded = int(cashadd)
        cashathand = m[0]['cash']
        db.execute("UPDATE users SET cash=:cash WHERE id=:id", cash=cashathand + cashadded, id=id)
        return redirect("/")
    else:
        return render_template("addcash.html")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    # user reached route via post
    if request.method == "POST":
        # ensure the blank was filled
        if not request.form.get("symbol"):
            return apology("Please enter the symbol of the company.")
        # get the written symbol of the company
        symbol = request.form.get("symbol")
        # use the lookup func to get the name, price, and symbol
        dicti = lookup(symbol)
        # check it is a valid symbol
        if not dicti:
            return apology("Stock symbol is unvalid")
        # assign single elements
        n = dicti["name"]
        p = dicti["price"]
        s = dicti["symbol"]
        # return quoted template with the assigned attributes
        return render_template("quoted.html", name=n, price=usd(p), symbol=s)
    # if it not post induce user to co-operate
    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():

    # user reached route via post
    if request.method == "POST":
        # ensure proper filling in the blanks
        if not request.form.get("username"):
            return apology("must provide username")

        elif not request.form.get("password"):
            return apology("must provide password")

        elif not request.form.get("confirmation"):
            return apology("must provide password confirmation")

        elif not request.form.get("password") == request.form.get("confirmation"):
            return apology("passwords shall match")
        datas = db.execute("SELECT username FROM users")
        for key in datas:
            if key == request.form.get("username"):
                return apology("The username has already been taken")
        # hash the password
        hashedpass = generate_password_hash(request.form.get("password"))
        # store the information in database
        usercreate = db.execute("INSERT INTO users (username,hash) VALUES(:username, :hash)",
                                username=request.form.get("username"), hash=hashedpass)

        if not usercreate:
            return apology("User could not be created")
        # testing
        flash("Hope this works")
        # remember the name :D
        session["user_id"] = usercreate
        # go to index page we are done here dude.
        return redirect(url_for("quote"))
    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    id = session['user_id']
    if request.method == "POST":
        if not request.form.get("shares"):
            return apology("Plase indicate the number of shares you would like to sell")
        if not request.form.get("symbol"):
            return apology("Select the symbol you want to sell pls")
        sellq = int(request.form.get("shares"))

        sym = request.form.get("symbol")
        data = db.execute("SELECT symbol,SUM(quantity) FROM portfolio WHERE id=:id AND symbol=:symbol GROUP BY symbol", id=id, symbol=sym)
        q = data[0]["SUM(quantity)"]
        c = db.execute("SELECT * FROM users WHERE id=:id", id=id)
        cashathand = c[0]['cash']
        if not sellq > 0:
            return apology("Selling quantity must be a positive int")
        if not sellq <= q:
            return apology("You cant sell more than you own")
        priceget = lookup(sym)
        price = priceget["price"]
        returnamount = sellq * price
        db.execute("UPDATE users SET cash=:cash WHERE id=:id", cash=cashathand + returnamount, id=id)
        db.execute("UPDATE portfolio SET quantity = :quantity WHERE id =:id AND symbol=:symbol", quantity=q - sellq, id=id, symbol=sym)
        db.execute("INSERT INTO history(id,price,quantity,symbol) VALUES (:id,:price,:quantity,:symbol)",
                   id=id, price=usd(price), quantity=0 - sellq, symbol=sym)
        if sellq - q == 0:
            db.execute("DELETE FROM portfolio WHERE id=:id AND symbol=:symbol", id=id, symbol=sym)
        return redirect("/")
    else:
        shares = db.execute("SELECT *FROM portfolio WHERE id =:id GROUP BY symbol", id=id)
        return render_template("sell.html", shares=shares)


def errorhandler(e):
    """Handle error"""
    return apology(e.name, e.code)


# listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)